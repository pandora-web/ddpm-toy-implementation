"""
A minimal Denoising Diffusion Probabilistic Model (DDPM) on a 2D toy dataset.

This project is intended as a small, readable research-code sample:
- generate a synthetic 2D mixture-of-Gaussians dataset;
- train a neural network to predict the noise added at a random diffusion step;
- reverse the diffusion process to generate new samples.

Run:
    pip install -r requirements.txt
    python train.py
"""

import math
import random
from pathlib import Path

import matplotlib.pyplot as plt
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset


SEED = 42
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
OUTPUT_DIR = Path("outputs")


def set_seed(seed: int) -> None:
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def make_mixture_data(n_samples: int = 30_000) -> torch.Tensor:
    """Sample points from eight Gaussian clusters arranged on a circle."""
    centers = []
    for i in range(8):
        angle = 2.0 * math.pi * i / 8
        centers.append([2.0 * math.cos(angle), 2.0 * math.sin(angle)])
    centers = torch.tensor(centers, dtype=torch.float32)

    labels = torch.randint(0, len(centers), (n_samples,))
    points = centers[labels] + 0.22 * torch.randn(n_samples, 2)
    return points


class NoisePredictor(nn.Module):
    """MLP that predicts the noise epsilon from x_t and timestep t."""

    def __init__(self, time_dim: int = 32, hidden_dim: int = 128):
        super().__init__()
        self.time_dim = time_dim
        self.net = nn.Sequential(
            nn.Linear(2 + time_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.SiLU(),
            nn.Linear(hidden_dim, 2),
        )

    def time_embedding(self, t: torch.Tensor) -> torch.Tensor:
        """Sinusoidal timestep embeddings, similar to those used in diffusion U-Nets."""
        half = self.time_dim // 2
        frequencies = torch.exp(
            -math.log(10_000) * torch.arange(half, device=t.device) / max(half - 1, 1)
        )
        angles = t.float().unsqueeze(1) * frequencies.unsqueeze(0)
        return torch.cat([torch.sin(angles), torch.cos(angles)], dim=1)

    def forward(self, x_t: torch.Tensor, t: torch.Tensor) -> torch.Tensor:
        embedding = self.time_embedding(t)
        return self.net(torch.cat([x_t, embedding], dim=1))


class DDPM:
    """Linear-beta DDPM scheduler and forward/reverse diffusion operations."""

    def __init__(self, timesteps: int = 300, beta_start: float = 1e-4,
                 beta_end: float = 0.02, device: str = DEVICE):
        self.timesteps = timesteps
        self.device = device
        self.betas = torch.linspace(beta_start, beta_end, timesteps, device=device)
        self.alphas = 1.0 - self.betas
        self.alpha_bars = torch.cumprod(self.alphas, dim=0)

    def add_noise(self, x_0: torch.Tensor, t: torch.Tensor,
                  noise: torch.Tensor) -> torch.Tensor:
        """Sample x_t directly using the closed-form forward process."""
        alpha_bar = self.alpha_bars[t].unsqueeze(1)
        return torch.sqrt(alpha_bar) * x_0 + torch.sqrt(1.0 - alpha_bar) * noise

    @torch.no_grad()
    def sample(self, model: nn.Module, n_samples: int) -> torch.Tensor:
        """Generate samples by iteratively denoising Gaussian noise."""
        model.eval()
        x = torch.randn(n_samples, 2, device=self.device)

        for step in reversed(range(self.timesteps)):
            t = torch.full((n_samples,), step, device=self.device, dtype=torch.long)
            predicted_noise = model(x, t)

            alpha = self.alphas[step]
            alpha_bar = self.alpha_bars[step]
            beta = self.betas[step]

            # Mean of the DDPM reverse transition.
            x = (x - (beta / torch.sqrt(1.0 - alpha_bar)) * predicted_noise) / torch.sqrt(alpha)

            # Add stochasticity except at the final denoising step.
            if step > 0:
                noise = torch.randn_like(x)
                x = x + torch.sqrt(beta) * noise

        return x


def train(steps: int = 5_000, batch_size: int = 256) -> None:
    set_seed(SEED)
    OUTPUT_DIR.mkdir(exist_ok=True)

    data = make_mixture_data()
    loader = DataLoader(TensorDataset(data), batch_size=batch_size, shuffle=True,
                        drop_last=True)
    loader_iter = iter(loader)

    diffusion = DDPM(device=DEVICE)
    model = NoisePredictor().to(DEVICE)
    optimizer = torch.optim.AdamW(model.parameters(), lr=2e-4)

    model.train()
    for step in range(1, steps + 1):
        try:
            (x_0,) = next(loader_iter)
        except StopIteration:
            loader_iter = iter(loader)
            (x_0,) = next(loader_iter)

        x_0 = x_0.to(DEVICE)
        t = torch.randint(0, diffusion.timesteps, (len(x_0),), device=DEVICE)
        noise = torch.randn_like(x_0)
        x_t = diffusion.add_noise(x_0, t, noise)

        predicted_noise = model(x_t, t)
        loss = nn.functional.mse_loss(predicted_noise, noise)

        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()

        if step % 500 == 0:
            print(f"step {step:5d}/{steps} | noise-prediction loss: {loss.item():.5f}")

    torch.save(model.state_dict(), OUTPUT_DIR / "noise_predictor.pt")

    generated = diffusion.sample(model, n_samples=5_000).cpu()
    real = data[:5_000]

    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    axes[0].scatter(real[:, 0], real[:, 1], s=3, alpha=0.35)
    axes[0].set_title("Real training distribution")
    axes[1].scatter(generated[:, 0], generated[:, 1], s=3, alpha=0.35)
    axes[1].set_title("DDPM-generated samples")
    for ax in axes:
        ax.set_aspect("equal")
        ax.grid(alpha=0.2)
        ax.set_xlabel("x")
        ax.set_ylabel("y")
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / "samples.png", dpi=160)
    print(f"Saved model and plot to: {OUTPUT_DIR.resolve()}")


if __name__ == "__main__":
    train()
