# Minimal DDPM on a 2D Toy Dataset

A compact, self-contained implementation of a Denoising Diffusion Probabilistic
Model (DDPM) using PyTorch. The model learns to generate points from an
eight-component Gaussian mixture.

## What this demonstrates

- PyTorch model implementation and training loop;
- sinusoidal timestep embeddings;
- the closed-form forward diffusion process;
- noise-prediction training objective;
- iterative reverse sampling;
- reproducible experiments and basic visualization.

## Setup

Python 3.9+ is recommended.

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
python train.py
```

The script automatically uses CUDA when available. It saves the trained
weights and a comparison plot in `outputs/`.

## Method

For a clean sample `x_0`, a timestep `t`, and Gaussian noise `epsilon`, the
forward process constructs:

`x_t = sqrt(alpha_bar_t) * x_0 + sqrt(1 - alpha_bar_t) * epsilon`

The MLP receives `x_t` and a sinusoidal embedding of `t`, and is trained to
predict `epsilon` using mean squared error. Sampling starts from standard
Gaussian noise and applies the learned reverse transitions from the final
timestep back to zero.

## Limitations and possible extensions

This is an educational toy experiment, not a state-of-the-art image-generation
system. The data are two-dimensional, the noise schedule is fixed and linear,
and the reverse variance is simplified. Useful extensions include comparing
noise schedules, implementing learned or posterior reverse variance, running
multiple seeds, reporting quantitative distribution metrics, and replacing
the MLP with a U-Net for image data.

## Important note

This is a small portfolio project. Before submitting it, run the experiment,
inspect the output, and make sure you can explain the forward process,
training objective, and reverse sampling equations in your own words.
